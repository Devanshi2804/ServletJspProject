package dto;

public class Booking 
{
	private String fromLocation;
	private String destLocation;
	private String email;
	private int userid;
	
	public Booking() {
		// TODO Auto-generated constructor stub
	}

	public Booking(String fromLocation, String destLocation, String email, int userid) {
		super();
		this.fromLocation = fromLocation;
		this.destLocation = destLocation;
		this.email = email;
		this.userid = userid;
	}

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getDestLocation() {
		return destLocation;
	}

	public void setDestLocation(String destLocation) {
		this.destLocation = destLocation;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}
	
}
