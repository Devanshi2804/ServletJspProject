package dto;

public class User 
{
	private int userId;
	private String userName;
	private String userCity;
	private String userPhone;
	private String userPassword;
	
	public User() {
	}
	public User(String userName, String userCity, String userPhone, String userPassword)
	{	
		this.userName = userName;
		this.userCity = userCity;
		this.userPhone = userPhone;
		this.userPassword = userPassword;
	}
	public User(int userId, String userName, String userCity, String userPhone, String userPassword) 
	{		
		this.userId = userId;
		this.userName = userName;
		this.userCity = userCity;
		this.userPhone = userPhone;
		this.userPassword = userPassword;
	}
	
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserCity() {
		return userCity;
	}
	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userCity=" + userCity + ", userPhone="
				+ userPhone + ", userPassword=" + userPassword + "]";
	}
}
