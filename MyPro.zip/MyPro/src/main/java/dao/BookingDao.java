package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.Booking;
import dto.User;

public class BookingDao 
{
	public ArrayList<Booking> list()
	{
		ArrayList<Booking> blist = new ArrayList<>();
		
		try(Connection cnn = DBConnection.getConnection())
		{
			Statement stm = cnn.createStatement();
			ResultSet rs = stm.executeQuery("select * from booking");
			
			while(rs.next()) {
				int id = rs.getInt("booking_id");
				String from = rs.getString("fromlocation");
				String dest = rs.getString("destlocation");
				String  mail = rs.getString("email");
				Booking bk = new Booking(from, dest, mail, 0);
				blist.add(bk);
			}
			
		}catch (Exception e) {
			System.err.println("List Booking Error : " + e.getMessage());			
		}
		
		return blist;
	}
	public boolean saveBooking(Booking booking) 
	{
		try(Connection cnn = DBConnection.getConnection())
		{
			PreparedStatement ps = cnn.prepareStatement("insert into "
					+ "booking(fromlocation,destlocation,email,userid) "
					+ "value(?,?,?,?)");
			ps.setString(1, booking.getFromLocation());
			ps.setString(2, booking.getDestLocation());
			ps.setString(3, booking.getEmail());
			ps.setInt(4, booking.getUserid());
			
			int i  = ps.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			System.err.println("Save Booking Error : " + e.getMessage());
			return false;
		}
	}
	
	
}
