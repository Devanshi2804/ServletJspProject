package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dto.Booking;
import dto.User;

public class UserDao 
{
	public boolean saveUser(User user) 
	{
		try(Connection cnn = DBConnection.getConnection())
		{
			PreparedStatement ps = cnn.prepareStatement("insert into "
					+ "user(user_name,user_city,user_phone,user_password) "
					+ "value(?,?,?,?)");
			ps.setString(1, user.getUserName());
			ps.setString(2, user.getUserCity());
			ps.setString(3, user.getUserPhone());
			ps.setString(4, user.getUserPassword());
			
			int i  = ps.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			System.err.println("Save User Error : " + e.getMessage());
			return false;
		}
	}

	public User authenticate(String phone, String password) 
	{
		User user = null;
		try(Connection cnn = DBConnection.getConnection())
		{
			PreparedStatement ps = cnn.prepareStatement("select user_id,user_name,user_city from "
					+ "user where user_phone=? and user_password=?");
					
			ps.setString(1, phone);
			ps.setString(2, password);
			
			ResultSet rs =  ps.executeQuery();
			
			if(rs.next()) {
				int id = rs.getInt("user_id");
				String name = rs.getString("user_name");
				String city = rs.getString("user_city");
				user = new User(id, name, city, phone, null);
			}
			
		} catch (Exception e) {
			System.err.println("Auth User Error : " + e.getMessage());			
		}
		return user;
	}
	

	public boolean updateUser(User user) 
	{
		try(Connection cnn = DBConnection.getConnection())
		{
			PreparedStatement ps = cnn.prepareStatement("update user"
					+ " set user_name=?,user_city=?,user_phone=? "
					+ " where user_id=?");
			ps.setString(1, user.getUserName());
			ps.setString(2, user.getUserCity());
			ps.setString(3, user.getUserPhone());
			ps.setInt(4, user.getUserId());
			
			int i  = ps.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			System.err.println("Update User Error : " + e.getMessage());
			return false;
		}
	}

	public boolean changePasswordUser(String oldpass, String newpass,int id) 
	{
		try(Connection cnn = DBConnection.getConnection())
		{
			PreparedStatement ps = cnn.prepareStatement("update user"
					+ " set user_password=? "
					+ " where user_id=? and user_password=?");
			ps.setString(1, newpass);
			ps.setInt(2, id);
			ps.setString(3, oldpass);
						
			int i  = ps.executeUpdate();
			if(i>0)
			{
				System.out.print("done");
				return true;
			}
			else
			{
				System.out.print(" Not done");
				return false;
			}
				
		} catch (Exception e) {
			System.err.println("Update User Error : " + e.getMessage());
			return false;
		}
	}

	
	
}
