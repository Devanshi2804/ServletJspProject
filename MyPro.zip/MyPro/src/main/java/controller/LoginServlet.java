package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDao;
import dto.User;

@WebServlet(name = "loginuser",urlPatterns = "/login")
public class LoginServlet extends HttpServlet 
{
	private UserDao userDao;
	
	private static final long serialVersionUID = 1L;
  
    public LoginServlet() {
    	userDao = new UserDao();        
    }

	
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException 
	{		
		String phone = request.getParameter("phone");
		String password = request.getParameter("password");		
		
		User user = userDao.authenticate(phone,password);
		HttpSession session = request.getSession();
		
		if(user!=null) {
			session.setAttribute("loginuser", user);
			response.sendRedirect("home.jsp");
		}else {
			session.setAttribute("loginstatus", false);	
			response.sendRedirect("user.jsp");
		}
		
	}

}
