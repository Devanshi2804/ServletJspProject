package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDao;
import dto.User;

@WebServlet(name = "changepass",urlPatterns = "/changepass")
public class ChangePasswordServlet extends HttpServlet 
{
	private UserDao userDao;
	
	private static final long serialVersionUID = 1L;
  
    public ChangePasswordServlet() {
    	userDao = new UserDao();        
    }

	
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session =  request.getSession();
		User loginUser = (User)session.getAttribute("loginuser");
		
		String oldpass = request.getParameter("oldpassword");
		String newpass = request.getParameter("newpassword");
		
		
		boolean status = userDao.changePasswordUser(oldpass,newpass,loginUser.getUserId());
		
		response.sendRedirect("login");
	}

}
