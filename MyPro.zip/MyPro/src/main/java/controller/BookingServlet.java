package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.BookingDao;
import dao.UserDao;
import dto.Booking;
import dto.User;

/**
 * Servlet implementation class BookingServlet
 */
@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	private BookingDao bookingDao;
	
    public BookingServlet() {
        
    	bookingDao = new BookingDao();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String from = request.getParameter("fromlocation");
		String dest = request.getParameter("destlocation");
		String email = request.getParameter("email");
		int userid = ((User)request.getSession().getAttribute("loginuser")).getUserId();
		
		Booking booking = new Booking(from, dest, email, userid);
		
		boolean status = bookingDao.saveBooking(booking);
		
		HttpSession session = request.getSession();
		session.setAttribute("bookingstatus", status);
				
		response.sendRedirect("home.jsp");
	}

}
